package com.dicoding.exam.optionalexam2

// TODO
fun minAndMax(number: Int): Int {
    return 0
}
